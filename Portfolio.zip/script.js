/* ============================================================
   JHONBY MANGUBAT — PORTFOLIO SCRIPTS
   Features:
   - Dark / Light theme toggle (persisted via localStorage)
   - Sticky nav with scrolled state
   - Smooth active link highlighting
   - Hamburger mobile menu
   - Scroll-reveal animations
   - Proficiency bar animations (triggered on scroll)
   - Contact form handling
============================================================ */

(function () {
  'use strict';

  /* ── Theme Toggle ──────────────────────────────────────── */
  const html        = document.documentElement;
  const themeToggle = document.getElementById('themeToggle');
  const themeIcon   = document.getElementById('themeIcon');

  // Restore saved theme or default to dark
  const savedTheme = localStorage.getItem('jm-theme') || 'dark';
  applyTheme(savedTheme);

  themeToggle.addEventListener('click', () => {
    const current = html.getAttribute('data-theme');
    applyTheme(current === 'dark' ? 'light' : 'dark');
  });

  function applyTheme(theme) {
    html.setAttribute('data-theme', theme);
    localStorage.setItem('jm-theme', theme);
    themeIcon.className = theme === 'dark'
      ? 'fa-solid fa-moon'
      : 'fa-solid fa-sun';
  }

  /* ── Sticky Nav + scrolled class ──────────────────────── */
  const navbar = document.getElementById('navbar');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
    highlightActiveLink();
  }, { passive: true });

  /* ── Active Nav Link Highlighting ─────────────────────── */
  const navLinks = document.querySelectorAll('.nav-links a');
  const sections = document.querySelectorAll('section[id]');

  function highlightActiveLink() {
    let currentId = '';
    sections.forEach(section => {
      const top = section.getBoundingClientRect().top;
      if (top <= 100) {
        currentId = section.id;
      }
    });
    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === '#' + currentId) {
        link.classList.add('active');
      }
    });
  }

  /* ── Hamburger Menu ────────────────────────────────────── */
  const hamburger = document.getElementById('hamburger');
  const navLinksContainer = document.getElementById('navLinks');

  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    navLinksContainer.classList.toggle('open');
  });

  // Close menu on link click
  navLinksContainer.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      hamburger.classList.remove('open');
      navLinksContainer.classList.remove('open');
    });
  });

  /* ── Scroll Reveal ─────────────────────────────────────── */
  // Attach reveal class to all major elements
  const revealTargets = [
    '.timeline-card',
    '.edu-card',
    '.cert-card',
    '.project-card',
    '.achievement-card',
    '.about-text',
    '.about-strengths',
    '.skill-group',
    '.proficiency-bars',
    '.contact-info',
    '.contact-form-wrap',
    '.hero-text',
    '.hero-visual',
  ];

  revealTargets.forEach(selector => {
    document.querySelectorAll(selector).forEach(el => {
      el.classList.add('reveal');
    });
  });

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, idx) => {
      if (entry.isIntersecting) {
        // Stagger siblings
        const siblings = entry.target.parentElement.querySelectorAll('.reveal');
        siblings.forEach((el, i) => {
          setTimeout(() => el.classList.add('visible'), i * 80);
        });
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });

  document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

  /* ── Proficiency Bar Animation ─────────────────────────── */
  const bars = document.querySelectorAll('.bar-item');

  const barObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const bar = entry.target;
        const pct = bar.getAttribute('data-pct');
        const fill = bar.querySelector('.bar-fill');
        if (fill) {
          fill.style.width = pct + '%';
        }
        barObserver.unobserve(bar);
      }
    });
  }, { threshold: 0.3 });

  bars.forEach(bar => barObserver.observe(bar));

  /* ── Contact Form ──────────────────────────────────────── */
  const form       = document.getElementById('contactForm');
  const formStatus = document.getElementById('formStatus');

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();

      const name    = form.name.value.trim();
      const email   = form.email.value.trim();
      const message = form.message.value.trim();

      // Basic validation
      if (!name || !email || !message) {
        showStatus('Please fill in all required fields.', 'error');
        return;
      }

      if (!isValidEmail(email)) {
        showStatus('Please enter a valid email address.', 'error');
        return;
      }

      // Simulate send (replace with fetch() to a real backend / EmailJS / Formspree)
      const submitBtn = form.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Sending...';

      setTimeout(() => {
        showStatus('Message sent! I\'ll get back to you soon.', 'success');
        form.reset();
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Send Message';
      }, 1500);
    });
  }

  function showStatus(msg, type) {
    formStatus.textContent = msg;
    formStatus.style.color = type === 'success'
      ? 'var(--accent-3)'
      : '#f87171';
    setTimeout(() => { formStatus.textContent = ''; }, 5000);
  }

  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  /* ── Smooth Scroll for CTA links (fallback) ────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', (e) => {
      const target = document.querySelector(anchor.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  /* ── Animate terminal lines on page load ───────────────── */
  const terminalLines = document.querySelectorAll('.terminal-body p');
  terminalLines.forEach((line, i) => {
    line.style.opacity = '0';
    setTimeout(() => {
      line.style.transition = 'opacity 0.4s ease';
      line.style.opacity = '1';
    }, 800 + i * 400);
  });

  /* ── Initial reveal for hero ───────────────────────────── */
  setTimeout(() => {
    document.querySelectorAll('#hero .reveal').forEach((el, i) => {
      setTimeout(() => el.classList.add('visible'), i * 120);
    });
  }, 100);

})();
